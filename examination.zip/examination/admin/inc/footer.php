 <style>
 .footeroption{background:#f9f9f9;color:#000;text-align:center;padding:20px;font-family: "Times New Roman", Times, serif;}
 </style>
 
</section>
<section class="footeroption">
		<h4><?php echo "Copyright 2019"; ?></h4>
	</section>
</div>
</body>
</html>