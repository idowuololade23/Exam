<?php

	$password = password_hash("m", PASSWORD_DEFAULT);
	echo "$password";

?>